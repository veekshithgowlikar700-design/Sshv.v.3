package com.srisaiganesh.sewing

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.ContactPage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.painterResource

data class Product(
    val id: String,
    val name: String,
    val model: String,
    val category: String,
    val image: Int,
    val verifiedPrice: Int?,
    val shopPrice: Int?,
    val source: String,
    val description: String
)

private val products = listOf(
    Product(
        "sewgo1",
        "Vidya Bernette Sew&Go 1",
        "Sew&Go 1",
        "Domestic",
        R.drawable.vidya_sewgo1,
        12399, 12899,
        "PriceHistory / Amazon listing • verified Oct 2026",
        "Mechanical beginner-friendly machine with 10 stitches, 5 mm stitch width and four presser feet."
    ),
    Product(
        "95t10",
        "Vidya 95T10 Tailor Machine",
        "95T10",
        "Tailor",
        R.drawable.vidya_95t10,
        9000, 9500,
        "TradeIndia seller listing • verified Oct 2026",
        "Manual tailor machine with two-thread lockstitch arrangement and heavy-duty construction."
    ),
    Product(
        "z7",
        "JACK Z7 AI Heavy-Duty",
        "Z7 / JK-58750D",
        "Heavy Duty",
        R.drawable.jack_z7,
        null, null,
        "JACK official product page • India price not publicly listed",
        "AI-assisted triple-transport lockstitch machine for leather, upholstery, bags, mattresses and other heavy materials."
    ),
    Product(
        "k7",
        "JACK K7 AI Interlock",
        "K7",
        "Interlock",
        R.drawable.jack_k7,
        124500, 125000,
        "Justdial verified-seller market listing • verified Oct 2026",
        "AI interlock machine for innerwear, sportswear, T-shirts and seam-cover applications."
    ),
    Product(
        "f6",
        "JACK F6 Lockstitch",
        "F6",
        "Lockstitch",
        R.drawable.jack_f6,
        24000, 24500,
        "Aajjo / TradeIndia seller listings • verified Oct 2026",
        "Direct-drive single-needle lockstitch machine for light-to-medium fabrics, up to 5000 spm."
    )
)

private val categories = listOf("All", "Domestic", "Tailor", "Lockstitch", "Overlock", "Interlock", "Heavy Duty")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SriSaiGaneshApp() }
    }
}

@Composable
fun SriSaiGaneshApp() {
    var tab by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Product?>(null) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF0A84FF),
            secondary = Color(0xFF5E5CE6),
            background = Color(0xFFF3F7FC),
            surface = Color.White
        )
    ) {
        if (selected != null) {
            ProductDetail(selected!!, onBack = { selected = null })
        } else {
            MainHome(
                tab = tab,
                onTab = { tab = it },
                onProduct = { selected = it }
            )
        }
    }
}

@Composable
fun MainHome(tab: Int, onTab: (Int) -> Unit, onProduct: (Product) -> Unit) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("All") }

    val filtered = products.filter {
        (category == "All" || it.category == category) &&
            (query.isBlank() || "${it.name} ${it.model} ${it.category}".contains(query, true))
    }

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            GlassBottomBar(tab, onTab)
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFFF8FBFF), Color(0xFFEFF4FA), Color(0xFFF8FBFF))
                    )
                ),
            contentPadding = PaddingValues(
                start = 16.dp, end = 16.dp, top = padding.calculateTopPadding() + 12.dp,
                bottom = padding.calculateBottomPadding() + 20.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                HeaderGlass()
            }
            if (tab == 0) {
                item { HeroCard(context) }
                item {
                    SearchGlass(query, { query = it })
                }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(categories) { c ->
                            FilterChip(
                                selected = category == c,
                                onClick = { category = c },
                                label = { Text(c) },
                                shape = RoundedCornerShape(20.dp)
                            )
                        }
                    }
                }
                item {
                    Text(
                        "Featured machines",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF121826)
                    )
                }
                items(filtered) { p ->
                    ProductCard(p, onClick = { onProduct(p) })
                }
            } else if (tab == 1) {
                item {
                    SectionTitle("All machines", "Browse the current catalogue")
                }
                item { SearchGlass(query, { query = it }) }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(categories) { c ->
                            FilterChip(category == c, { category = c }, label = { Text(c) })
                        }
                    }
                }
                items(filtered) { p -> ProductCard(p) { onProduct(p) } }
            } else {
                item { ContactPage(context) }
            }
        }
    }
}

@Composable
fun HeaderGlass() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text("SRI SAI GANESH", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0A84FF))
            Text("Sewing Machines", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF101522))
            Text("Medchal • Telangana", fontSize = 13.sp, color = Color(0xFF667085))
        }
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color.White.copy(alpha = .72f))
                .border(1.dp, Color.White, RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.ShoppingBag, null, tint = Color(0xFF0A84FF))
        }
    }
}

@Composable
fun HeroCard(context: android.content.Context) {
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(30.dp)
    ) {
        Column(modifier = Modifier.padding(22.dp)) {
            Text("Machines for every stitch.", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                "Domestic, tailor, lockstitch, interlock & heavy-duty machines.",
                color = Color(0xFF667085),
                modifier = Modifier.padding(top = 6.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 18.dp)) {
                Button(
                    onClick = { openWhatsApp(context) },
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(Icons.Default.Chat, null)
                    Spacer(Modifier.width(7.dp))
                    Text("WhatsApp")
                }
                OutlinedButton(
                    onClick = { openMaps(context) },
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(Icons.Default.LocationOn, null)
                    Spacer(Modifier.width(7.dp))
                    Text("Visit shop")
                }
            }
        }
    }
}

@Composable
fun SearchGlass(query: String, onQuery: (String) -> Unit) {
    GlassCard(shape = RoundedCornerShape(22.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 16.dp, vertical = 13.dp)) {
            Icon(Icons.Default.Search, null, tint = Color(0xFF667085))
            Spacer(Modifier.width(10.dp))
            BasicTextField(
                value = query,
                onValueChange = onQuery,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                decorationBox = { inner ->
                    if (query.isEmpty()) Text("Search machine or model...", color = Color(0xFF98A2B3))
                    inner()
                }
            )
        }
    }
}

@Composable
fun ProductCard(p: Product, onClick: () -> Unit) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(28.dp)
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(p.image),
                contentDescription = p.name,
                modifier = Modifier
                    .size(118.dp)
                    .clip(RoundedCornerShape(22.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(p.category.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0A84FF))
                Text(p.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(p.model, fontSize = 12.sp, color = Color(0xFF667085), modifier = Modifier.padding(top = 2.dp))
                Spacer(Modifier.height(8.dp))
                if (p.shopPrice != null) {
                    Text("₹${p.shopPrice}", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF111827))
                    Text("Shop price • ₹500 over verified online price", fontSize = 10.sp, color = Color(0xFF667085))
                } else {
                    Text("Price on request", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF111827))
                    Text("Exact India online price not publicly listed", fontSize = 10.sp, color = Color(0xFF667085))
                }
            }
            Icon(Icons.Default.ChevronRight, null, tint = Color(0xFF98A2B3))
        }
    }
}

@Composable
fun ProductDetail(p: Product, onBack: () -> Unit) {
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFFF8FBFF), Color(0xFFEFF4FA))))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Text("Machine details", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Image(
                    painter = painterResource(p.image),
                    contentDescription = p.name,
                    modifier = Modifier.fillMaxWidth().height(270.dp).clip(RoundedCornerShape(30.dp)),
                    contentScale = ContentScale.Crop
                )
            }
            item {
                GlassCard(shape = RoundedCornerShape(30.dp)) {
                    Column(Modifier.padding(22.dp)) {
                        Text(p.category.uppercase(), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0A84FF))
                        Text(p.name, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Model ${p.model}", color = Color(0xFF667085), modifier = Modifier.padding(top = 4.dp))
                        Spacer(Modifier.height(14.dp))
                        if (p.shopPrice != null) {
                            Text("₹${p.shopPrice}", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                            Text("Our shop price", color = Color(0xFF667085))
                            Text("Verified online: ₹${p.verifiedPrice} + ₹500", fontSize = 12.sp, color = Color(0xFF667085))
                        } else {
                            Text("Price on request", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Spacer(Modifier.height(14.dp))
                        Text(p.description, fontSize = 15.sp, color = Color(0xFF475467), lineHeight = 22.sp)
                        Spacer(Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, null, tint = Color(0xFF0A84FF), modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(7.dp))
                            Text(p.source, fontSize = 11.sp, color = Color(0xFF667085))
                        }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { openWhatsApp(context, "Hi Sri Sai Ganesh Sewing Machines, I am interested in ${p.name} (${p.model}).") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Icon(Icons.Default.Chat, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Enquire")
                    }
                    OutlinedButton(
                        onClick = { callShop(context) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Icon(Icons.Default.Call, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Call")
                    }
                }
            }
        }
    }
}

@Composable
fun ContactPage(context: android.content.Context) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionTitle("Sri Sai Ganesh Sewing Machines", "Your local sewing machine store")
        GlassCard(shape = RoundedCornerShape(30.dp)) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                ContactRow(Icons.Default.LocationOn, "Raithu Bazar, Medchal", "Secunderabad, Telangana 501401")
                ContactRow(Icons.Default.Call, "9866999286", "Tap to call the shop")
                ContactRow(Icons.Default.Chat, "WhatsApp enquiries", "Fast product and price enquiries")
                Text("Beside Canara Bank ATM", fontWeight = FontWeight.Bold, color = Color(0xFF111827))
                Button(
                    onClick = { openMaps(context) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(Icons.Default.LocationOn, null)
                    Spacer(Modifier.width(7.dp))
                    Text("Open location")
                }
                OutlinedButton(
                    onClick = { openWhatsApp(context) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(Icons.Default.Chat, null)
                    Spacer(Modifier.width(7.dp))
                    Text("Chat on WhatsApp")
                }
            }
        }
        GlassCard(shape = RoundedCornerShape(30.dp)) {
            Column(Modifier.padding(22.dp)) {
                Text("Price policy", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Online reference prices are checked when the catalogue is updated. Where an exact India online price is verified, the displayed shop price is ₹500 higher. Final availability, GST, table/stand, motor and delivery charges can vary.",
                    color = Color(0xFF667085),
                    lineHeight = 21.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }
}

@Composable
fun ContactRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier.size(44.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFFEAF3FF)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = Color(0xFF0A84FF)) }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Color(0xFF667085), fontSize = 13.sp)
        }
    }
}

@Composable
fun SectionTitle(title: String, subtitle: String) {
    Column {
        Text(title, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Text(subtitle, color = Color(0xFF667085), modifier = Modifier.padding(top = 3.dp))
    }
}

@Composable
fun GlassBottomBar(tab: Int, onTab: (Int) -> Unit) {
    NavigationBar(containerColor = Color.White.copy(alpha = .82f)) {
        NavigationBarItem(tab == 0, { onTab(0) }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
        NavigationBarItem(tab == 1, { onTab(1) }, icon = { Icon(Icons.Default.GridView, null) }, label = { Text("Catalogue") })
        NavigationBarItem(tab == 2, { onTab(2) }, icon = { Icon(Icons.Default.ContactPage, null) }, label = { Text("Contact") })
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: RoundedCornerShape = RoundedCornerShape(24.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .shadow(12.dp, shape, ambientColor = Color(0x22000000), spotColor = Color(0x22000000))
            .clip(shape)
            .background(Color.White.copy(alpha = .70f))
            .border(1.dp, Color.White.copy(alpha = .90f), shape),
        content = content
    )
}

fun openWhatsApp(context: android.content.Context, message: String = "Hi Sri Sai Ganesh Sewing Machines, I want to know today's machine prices.") {
    val url = "https://wa.me/919866999286?text=" + Uri.encode(message)
    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
}

fun callShop(context: android.content.Context) {
    context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:9866999286")))
}

fun openMaps(context: android.content.Context) {
    val query = Uri.encode("Sri Sai Ganesh Sewing Machines, Raithu Bazar, Medchal, Telangana")
    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$query")))
}
